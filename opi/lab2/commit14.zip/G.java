public class G extends null {

    String kk();

    void aa();

    public long ac() {
        return 333;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public Object rr() {
        return null;
    }
}
