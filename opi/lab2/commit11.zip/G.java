public class G extends null {

    String kk();

    void aa();
}
