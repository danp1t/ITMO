public class D {

    private byte e = 1;

    private String i = "test";

    public float ff() {
        return 3.14;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public void ab() {
        System.out.println("\n");
    }

    public Object pp() {
        return this;
    }

    public double ad() {
        return 11.09;
    }
}
