public class E {

    private double d = 100.500;

    private double i = 100.500;

    public Object pp() {
        return this;
    }

    public int ae() {
        return 9;
    }

    public double ee() {
        return 500.100;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public long dd() {
        return 33;
    }
}
