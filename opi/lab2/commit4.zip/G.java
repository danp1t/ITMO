public interface G {

    String kk();

    void aa();
}
