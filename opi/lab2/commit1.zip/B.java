public class B implements G {

    private double e = 100.500;

    private byte h = 1;

    public int cc() {
        return 13;
    }

    public byte oo() {
        return 4;
    }

    public String kk() {
        return "No";
    }

    public void aa() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}
