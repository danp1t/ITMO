public class E {

    private double d = 100.500;

    private double i = 100.500;

    public Object pp() {
        return this;
    }

    public int ae() {
        return 9;
    }
}
