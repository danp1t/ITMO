public class E extends null {

    private double d = 100.500;

    private double i = 100.500;

    public Object pp() {
        return this;
    }

    public int ae() {
        return 9;
    }

    public double ee() {
        return 500.100;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public long dd() {
        return 33;
    }

    public int cc() {
        return 42;
    }

    public byte oo() {
        return 4;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }
}
