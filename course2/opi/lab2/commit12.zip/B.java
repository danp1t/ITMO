public class B extends null implements G {

    private double e = 100.500;

    private byte h = 1;

    public int cc() {
        return 13;
    }

    public byte oo() {
        return 4;
    }

    public String kk() {
        return "No";
    }

    public void aa() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public double ad() {
        return 9.11;
    }

    public void ab() {
        return;
    }

    public long dd() {
        return 100500;
    }

    public double ee() {
        return 500.100;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object pp() {
        return this;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object rr() {
        return null;
    }
}
