public class G extends null {

    String kk();

    void aa();

    public long ac() {
        return 333;
    }
}
